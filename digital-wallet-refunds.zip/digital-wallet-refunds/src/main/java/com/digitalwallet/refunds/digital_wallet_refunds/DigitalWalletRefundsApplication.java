package com.digitalwallet.refunds.digital_wallet_refunds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigitalWalletRefundsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigitalWalletRefundsApplication.class, args);
	}

}
