package com.digitalwallet.refunds.digital_wallet_refunds;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalWalletRefundsApplicationTests {

	@Test
	void contextLoads() {
	}

}
